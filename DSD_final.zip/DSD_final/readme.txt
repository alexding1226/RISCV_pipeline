To run RTL simulation, just include all the .v files without _syn in their names.
To run post_syn simulation, just include the *_syn.v & *_syn.sdf along with tsmc13.v.

Cyle time for post-syn simulation : 
    Baseline:   2.31 ns
    L2Cache:    3.5 ns
    BrPred:     3.4 ns
    Compression: 3.3 ns
    Final:      3.5ns

